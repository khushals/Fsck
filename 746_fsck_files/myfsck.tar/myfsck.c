/*

Author: Khushal Shah
Date: 2/18/2014

A file system check utility.

Part 1: Read partition table

*/

#include"myfsck.h"

int main(int argc,char** argv)
{
	
	char* disk_image;
	int partition;	
//	char buf[sector_size_bytes];
	int sector=0;
	
	fillArgs(argc,argv,&partition,&disk_image);		

	if( (device = open(disk_image,O_RDWR)) == -1) {
		
		perror("Could not open the device file");
		exit(-1);
	}
	
//	read_device(device,0,1,buf);	
	partitionTableEntry(partition,sector);
//	read_sectors(0,1,buf);	    
//	print_sector(buf);	
	
	return 0;
}


